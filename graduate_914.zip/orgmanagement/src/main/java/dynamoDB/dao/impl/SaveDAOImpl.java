package dynamoDB.dao.impl;

import amazon.util.DynamoDBUtil;
import dynamoDB.dao.SaveDAO;

public class SaveDAOImpl implements SaveDAO{
	
	public String save(Object object){
		final DynamoDBUtil dynamoDBUtil = new DynamoDBUtil();
		return dynamoDBUtil.save(object);		
	}
	
	public void saveBatch(Object... object){
		final DynamoDBUtil dynamoDBUtil = new DynamoDBUtil();
		dynamoDBUtil.batchSave(object);		
	}
}
