package com.orgmanagement.webapp.controller.rest;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dynamoDB.service.DeleteService;
import dynamoDB.service.SaveService;
import com.orgmanagement.webapp.util.Base64Util;
import com.google.gson.Gson;
import com.orgmanagement.webapp.dao.MemberDAO;
import com.orgmanagement.webapp.dao.MemoryProjectDAO;
import com.orgmanagement.webapp.entity.Member;
import com.orgmanagement.webapp.entity.MemoryProject;
import com.orgmanagement.webapp.util.AttributeCheck;
import com.orgmanagement.webapp.util.CookieUtil;
import com.orgmanagement.webapp.util.EmailUtil;
import com.orgmanagement.webapp.util.SecurityMD5;
import com.orgmanagement.webapp.util.UUIDGenerator;
import com.orgmanagement.webapp.util.entity.WebResponse;

import amazon.cloudwatch.logback.entity.LogReport;

@Path("/")
@Controller
public class MemberController {
	final ApplicationContext CONTEXT_RDS = new ClassPathXmlApplicationContext("spring-module-rds.xml");

	private static Logger logger = LoggerFactory.getLogger(MemberController.class);

	@POST
	@Path("/register")
	@Consumes("application/json")
	public Response register(Member member, @Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		// init DAO
		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		final SecurityMD5 securityMD5 = new SecurityMD5();
		final UUIDGenerator uuidGenerator = new UUIDGenerator();
		// init func
		final AttributeCheck attributeCheck = new AttributeCheck();
		final Gson gson = new Gson();
		// init variable
		final WebResponse webResponse = new WebResponse();
		System.out.println("test");
		if (true) {

			
			

			final boolean flag = memberDAO.checkAccount(member.getMemberAccount());
			if (flag) {
				
				
				member.setMemberEmail(member.getMemberAccount());
				try {
					member.setMemberPassword(securityMD5.encryptWords(member.getMemberPassword()));
				} catch (NoSuchAlgorithmException e) {
					e.printStackTrace();
				}
				
				memberDAO.insert(member); //最後才insert
				webResponse.OK(); //通常放在最後
			} else {
				webResponse.CONFLICT();
				webResponse.getError().setMessage("memberAccount has already been taken");
				webResponse.setData(webResponse.getError());
			}
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}

	
	
	
	
	// 儲存cookie
//			cookieUtil.setLoginTokenCookie(loginToken, response);

	// Save Member info
//			Member member = new Member();
//			member.setLoginId(login.getLoginId());
//			member.setMemberAccount(login.getMemberAccount());

////		member.setMemberNo(uuidGenerator.getUUID());

//
//			login.setPassword(null);
//			webResponse.setData(login);
//			webResponse.OK();
	
	
	/**
	 * 成功註冊頁
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/registerSuccess", method = RequestMethod.GET)
	public ModelAndView registerSuccess(HttpServletRequest request, HttpSession session) {
		final Member member = (Member) session.getAttribute("member");
		final ModelAndView model = new ModelAndView();
		if(member != null) {
			model.setViewName("redirect:/");
		} else {
			model.setViewName("registerSuccess");
		}	
		return model;
	}
	
	/**
	 * 登入頁
	 * 
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest request, HttpSession session) {
		final Member member = (Member) session.getAttribute("member");
		final ModelAndView model = new ModelAndView();
		if(member == null){
			if(session.getAttribute("errorMsg") != null){
				final String errorMsg = session.getAttribute("errorMsg").toString();
				session.removeAttribute("errorMsg");
				model.addObject("errorMsg", errorMsg);
			}
			model.setViewName("login");
		} else {
			model.setViewName("redirect:/");
		}
		return model;
	}
	

	/**
	 * 註冊會員
	 * 
	 * @param member
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/insertMember", method = RequestMethod.POST)
	public ModelAndView insertMember(@ModelAttribute Member member, HttpServletRequest request, HttpSession session) {
		final ModelAndView model = new ModelAndView();
		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		final SecurityMD5 securityMD5 = new SecurityMD5();
		// final UUIDGenerator uuidGenerator = new UUIDGenerator();
		try {
			member.setMemberPassword(securityMD5.encryptWords(member.getMemberPassword()));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		member.setMemberEmail(member.getMemberAccount());
		// member.setMemberNO("member_" + uuidGenerator.getUUID());
		memberDAO.insert(member);

		//系統管理員
				final List<Member>managerList = memberDAO.getListbyIdentity(1);
				//通知管理員
				final EmailUtil mail = new EmailUtil();
				mail.contactEmailManage(member,managerList, request);	
				model.setViewName("redirect:/registerSuccess");
				final LogReport logReport = new LogReport();
				logReport.setSubject(member);
				logReport.setFunction("insertMember");
				logReport.setVerb("註冊");
				logReport.setMessage(member.getMemberName() + "申請註冊");
				logger.info(new Gson().toJson(logReport));
				return model;
	}

//
//	/**
//	 * 檢查帳號重複
//	 * 
	@POST
	@Path("/checkAvailable/memberAccount")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response checkMemoryProjectName(Member member, @Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		// init DAO
		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		// init func

		// init variable
		final WebResponse webResponse = new WebResponse();
		if (true) {
			final boolean flag = memberDAO.checkAccount(member.getMemberAccount());
			if (flag) {
				webResponse.OK();
			} else {
				webResponse.CONFLICT();
				webResponse.getError().setMessage("memberAccount has already been taken");
				webResponse.setData(webResponse.getError());
			}
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
//	
//	/**
//	 * 檢查登入
//	 * @param member
//	 * @param session
//	 * @param request
//	 * @return
//	 * @throws IOException
//	 */
//	@RequestMapping(value = "/checkLogin", method = RequestMethod.POST)
//	public ModelAndView checkLogin(@ModelAttribute Member member, HttpSession session, HttpServletRequest request)throws IOException {
//		final ModelAndView model = new ModelAndView();
//		final SecurityMD5 securityMD5 = new SecurityMD5();
//		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
//		final MemberIdentityDAO memberIdentityDAO = (MemberIdentityDAO) CONTEXT_RDS.getBean("memberIdentityDAO");
//		final LogReport logReport = new LogReport();
//		try {
//			member.setPassword(securityMD5.encryptWords(member.getPassword()));
//		} catch (NoSuchAlgorithmException e) {
//			e.printStackTrace();
//		}
//		//身分判斷
//		final List<MemberIdentity>memberIdentityList=memberIdentityDAO.getList(member);
//		member.setMemberIdentityList(memberIdentityList);
//		member = memberDAO.checkLogin(member);
//		logReport.setSubject(member);
//		logReport.setFunction("checkLogin");
//		logReport.setVerb("登入");
//		if (member.isLogin()) {
//			session.setAttribute("loginMember", member);
//			model.setViewName("redirect:" + request.getHeader("referer"));									
//			logReport.setMessage(member.getName() + " 登入成功");
//		} else {
//			session.setAttribute("errorMsg", "無效的帳號密碼或未驗證");
//			model.setViewName("redirect:/login");
//			logReport.setMessage(member.getAccount() + " 登入失敗");
//		}
//		logger.info(new Gson().toJson(logReport));
//		return model;
//	}
	
	/**
	 * 使用者管理頁
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/manageMember", method = RequestMethod.GET)
	public ModelAndView manageMember(HttpServletRequest request, HttpSession session) {
		final Member member = (Member) session.getAttribute("Member");
		final ModelAndView model = new ModelAndView();
		if(member != null && member.getIsManager() != 0) {
			if(session.getAttribute("successMsg") != null) {
				final String successMsg = session.getAttribute("successMsg").toString();			
				session.removeAttribute("successMsg");
				model.addObject("successMsg",successMsg);
			}		
			model.setViewName("manageMember");
			final LogReport logReport = new LogReport(); 
			logReport.setSubject(member);
			logReport.setVerb("進入使用者管理頁 manageMember");
			logReport.setMessage(member.getMemberAccount() + "進入使用者管理頁 manageMember");
			logger.info(new Gson().toJson(logReport));
		} else {
			model.setViewName("redirect:/login");
		}
		return model;
	}
	
	
	
	
	/**
	 * 修改個人資料頁
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/updateMember", method = RequestMethod.GET)
	public ModelAndView updateMember(HttpServletRequest request, HttpSession session) {
		final Member member = (Member) session.getAttribute("member");
		final ModelAndView model = new ModelAndView();
		if(member != null){
			final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");				
			if(session.getAttribute("successMsg")!=null){
				final String successMsg=(String) session.getAttribute("successMsg");
				session.removeAttribute("successMsg");
				model.addObject("successMsg", successMsg);
			}
			Member member2 = new Member();
			member.setMemberAccount(member.getMemberAccount());				
			member2 = memberDAO.get(member);
			model.addObject("member", member);
			model.setViewName("updateMember");
		} else {
			model.setViewName("redirect:/");
		}
		return model;
	}
	
	/**
	 * 修改個人資料
	 * @param member
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/updateMember", method = RequestMethod.POST)
	public ModelAndView updateMember(@ModelAttribute Member member, HttpSession session, HttpServletRequest request) {
		final Member member2 = (Member)session.getAttribute("member");
		final ModelAndView model = new ModelAndView();
		if(member != null){
			final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
			//final MemberIdentityDAO memberIdentityDAO = (MemberIdentityDAO) CONTEXT_RDS.getBean("memberIdentityDAO");		
			member.setMemberAccount(member.getMemberAccount());
			memberDAO.update(member, member);
			//身分判斷
			final List<Member>memberList = memberDAO.getList(member);
			member.setList(memberList);			
			member = memberDAO.get(member);		
			session.removeAttribute("member");
			session.setAttribute("member", member);		
			model.setViewName("redirect:/updateMember");
			session.setAttribute("successMsg", "修改成功!");
			final LogReport logReport = new LogReport(); 
			logReport.setSubject(member);
			logReport.setVerb("更新個人資料");
			logReport.setObject(member);
			logReport.setMessage(member.getMemberName() + " 更新個人資料");
			logger.info(new Gson().toJson(logReport));
		} else {
			model.setViewName("redirect:/");
		}	
		return model;
	}
	
	
	/**
	 * 修改密碼頁
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/updatePassword", method = RequestMethod.GET)
	public ModelAndView updatePassword(HttpServletRequest request, HttpSession session) {
		final Member member = (Member) session.getAttribute("member");
		final ModelAndView model = new ModelAndView();
		if(member != null){
			final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
			boolean flag;
			if(session.getAttribute("flag")!=null){
				flag = (Boolean) session.getAttribute("flag");
				session.removeAttribute("flag");
				model.addObject("flag", flag);
			}
			Member member2 = new Member();
			member.setMemberAccount(member.getMemberAccount());
			member2 = memberDAO.get(member);
			model.addObject("member", member);
			model.setViewName("updatePassword");
		} else {
			model.setViewName("redirect:/");
		}
		return model;
	}
	
	/**
	 * 修改密碼
	 * @param session
	 * @param password
	 * @param oldPassword
	 * @return
	 */
	@RequestMapping(value = "/updatePassword", method = RequestMethod.POST)
	public ModelAndView updatePassword(HttpSession session, String password, String oldPassword) {
		final ModelAndView model = new ModelAndView();	
		final Member member = (Member)session.getAttribute("member");		
		if(member != null){
			final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
			final SecurityMD5 securityMD5 = new SecurityMD5();
			try {
				oldPassword = securityMD5.encryptWords(oldPassword);
				password = securityMD5.encryptWords(password);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			Member member2 = new Member();
			member.setMemberAccount(member.getMemberAccount());
			member.setMemberPassword(oldPassword);
			member2 = memberDAO.checkLogin(member);
			if(member.isLogin()){
				member.setMemberPassword(password);
				memberDAO.updatePassword(member);
				session.setAttribute("flag", true);
			} else {
				session.setAttribute("flag", false);
			}
				
			model.setViewName("redirect:/updatePassword");
		} else {
			model.setViewName("redirect:/login");
		}	
		return model;
	}
	
	/**
	 * 忘記密碼頁
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/forgetPassword", method = RequestMethod.GET)
	public ModelAndView forgetPassword(HttpSession session) {
		final ModelAndView model = new ModelAndView();
		final Member member = (Member)session.getAttribute("member");
		if(member == null){
			model.setViewName("forgetPassword");
		}else
			model.setViewName("redirect:/");
		return model;
	}
	
	/**
	 * 忘記密碼頁(after send email)
	 * @return
	 */
	@RequestMapping(value = "/forgetPassword2", method = RequestMethod.GET)
	public ModelAndView forgetPassword2(HttpSession session) {
		final ModelAndView model = new ModelAndView();
		final Member member = (Member)session.getAttribute("member");
		if(member == null){
			model.setViewName("forgetPassword2");
		}else
			model.setViewName("redirect:/");
		return model;
	}
	
	/**
	 * 忘記密碼錯誤訊息頁(after send email)
	 * @return
	 */
	@RequestMapping(value = "/forgetPasswordFail", method = RequestMethod.GET)
	public ModelAndView forgetPasswordFail(HttpSession session) {
		final ModelAndView model = new ModelAndView();
		final Member member = (Member)session.getAttribute("member");
		if(member == null){
			model.setViewName("forgetPasswordFail");
		}else
			model.setViewName("redirect:/");
		return model;
	}
	
	/**
	 * 重設密碼驗證信
	 * @param account
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/sendPasswordConfirm", method = RequestMethod.POST)
	public ModelAndView sendPasswordConfirm(String account, HttpServletRequest request) {
		final ModelAndView model = new ModelAndView();
		//final UUIDGenerator uuidGenerator = new UUIDGenerator();
		MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		//新系統帳號
		Member member = new Member();
		member.setMemberAccount(account);
		member = memberDAO.get(member);
		//用email取得帳號(舊系統帳號)
		List<Member>memberList=new ArrayList<Member>();
		memberList=memberDAO.getListbyEmail(account);
		if(member.getMemberAccount()!=null && member.getStatus()==1){
			model.setViewName("redirect:/forgetPassword2");
			//member.setResetNO(uuidGenerator.getUUID());
			//memberDAO.updateResetNO(member);			
			EmailUtil mail = new EmailUtil();
			mail.passwordConfirm(member, request);	
		}else if(memberList.size()>0){
			model.setViewName("redirect:/forgetPassword2");
			for(Member member2:memberList){
				//member2.setResetNO(uuidGenerator.getUUID());
				//memberDAO.updateResetNO(member2);			
			}
			EmailUtil mail = new EmailUtil();
			mail.passwordConfirmbyEmail(memberList, request);
		}else
			model.setViewName("redirect:/forgetPasswordFail");
		return model;
	}
	
	/**
	 * 重設密碼頁
	 * @param aid
	 * @return
	 */
	@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
	public ModelAndView resetPassword(String aid) {
		final ModelAndView model = new ModelAndView();
		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		Member member = new Member();
		//member.setResetNO(aid);
		//member = memberDAO.getByResetNO(member);
		if(member.getMemberAccount()!=null && member.getStatus()==1){
			model.addObject("aid", aid);
			model.setViewName("resetPassword");
		}else
			model.setViewName("redirect:/forgetPasswordFail");
		return model;
	}
	
	/**
	 * 重設密碼成功頁
	 * @return
	 */
	@RequestMapping(value = "/resetPassword2", method = RequestMethod.GET)
	public ModelAndView resetPassword2() {
		final ModelAndView model = new ModelAndView();
		model.setViewName("resetPassword2");
		return model;
	}
	
	/**
	 * 重設密碼
	 * @param password
	 * @param aid
	 * @return
	 */
	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public ModelAndView resetPassword(String password, String aid) {
		final ModelAndView model = new ModelAndView();
		final MemberDAO memberDAO = (MemberDAO) CONTEXT_RDS.getBean("memberDAO");
		Member member = new Member();
		SecurityMD5 securityMD5 = new SecurityMD5();
		
		
		if(member.getMemberAccount()!=null && member.getStatus()==1){
			try {
				password = securityMD5.encryptWords(password);
			}catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			member.setMemberPassword(password);
			memberDAO.updatePassword(member);
			model.setViewName("redirect:/resetPassword2");
		}else
			model.setViewName("redirect:/forgetPasswordFail");			
		return model;
	}
	
	/**
	 * 登出
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView model = new ModelAndView("redirect:/");
		request.getSession().invalidate();
		return model;
	}
	
	//日期轉換格式 (防止date空值)
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}	
	
	

	@POST
	@Path("/logout")
	@Consumes("application/json")
	public Response logout(@Context HttpServletRequest request, @Context HttpServletResponse response) {
		// 清除cookie
		final CookieUtil cookieUtil = new CookieUtil();
		cookieUtil.cleanTokenCookie(request, response);
		// init variable
		final WebResponse webResponse = new WebResponse();
		webResponse.OK();
		return Response.status(webResponse.getStatusCode()).build();
	}
}
