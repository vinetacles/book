package com.orgmanagement.webapp.controller.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.annotations.GZIP;
import org.springframework.stereotype.Controller;

import com.orgmanagement.webapp.dao.MemoryProjectInvitedDAO;
import com.orgmanagement.webapp.entity.MemoryProjectInvited;
import com.orgmanagement.webapp.util.entity.WebResponse;

@Path("/test")
@Controller
public class TestRestController {
	
	@GET
	@GZIP
	@Path("/{testId}")
	public Response get(@PathParam("testId") String testId, @Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		final WebResponse webResponse = new WebResponse();
		if (true) {
			webResponse.setData(testId);
			webResponse.OK();
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	

}
