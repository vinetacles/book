package com.orgmanagement.webapp.entity.option;

import java.util.HashMap;

public class MemoryProjectInvitedOptionMapping {
	private static final HashMap<Integer, String> eventSourceHashMap = getEventSourceHashMap();
	private static final HashMap<Integer, String> eventInvitedOrganizationHashMap = getEventInvitedOrganizationHashMap();
	
	public static HashMap<Integer, String> getEventSourceHashMap() {
		final HashMap<Integer, String>hashMap = new HashMap<>();
		hashMap.put(1, "自行搜尋");
		hashMap.put(2, "他人推薦");
		hashMap.put(3, "主管交辦");
		hashMap.put(4, "業務交接");
		hashMap.put(5, "曾經上過相關課程");
		hashMap.put(6, "主動開發");
		hashMap.put(7, "其他");
		return hashMap;
	}
	
	public String getEventSourceString (Integer i) {
		return eventSourceHashMap.get(i);	
	}
	
	public static HashMap<Integer, String> getEventInvitedOrganizationHashMap() {
		final HashMap<Integer, String>hashMap = new HashMap<>();
		hashMap.put(1, "財務社工中心");
		hashMap.put(2, "馴錢師");
		hashMap.put(3, "個人");
		hashMap.put(4, "信扶專案");
		hashMap.put(5, "其他");
		return hashMap;
	}
	
	public String getEventInvitedOrganizationString (Integer i) {
		return eventInvitedOrganizationHashMap.get(i);	
	}
}
