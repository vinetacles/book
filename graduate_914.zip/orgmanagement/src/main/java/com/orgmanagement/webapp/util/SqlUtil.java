package com.orgmanagement.webapp.util;

import com.orgmanagement.webapp.util.entity.LikeGenerator;
import com.orgmanagement.webapp.util.entity.LimitGenerator;
import com.orgmanagement.webapp.util.entity.OrderGenerator;

public class SqlUtil {
	private LimitGenerator limitGenerator = new LimitGenerator();
	private LikeGenerator likeGenerator = new LikeGenerator();
	private OrderGenerator orderGenerator = new OrderGenerator();
	
	public LimitGenerator getLimitGenerator() {
		return limitGenerator;
	}
	public void setLimitGenerator(LimitGenerator limitGenerator) {
		this.limitGenerator = limitGenerator;
	}	
	public LikeGenerator getLikeGenerator() {
		return likeGenerator;
	}
	public void setLikeGenerator(LikeGenerator likeGenerator) {
		this.likeGenerator = likeGenerator;
	}
	public OrderGenerator getOrderGenerator() {
		return orderGenerator;
	}
	public void setOrderGenerator(OrderGenerator orderGenerator) {
		this.orderGenerator = orderGenerator;
	}
}
