package com.orgmanagement.webapp.controller.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.resteasy.annotations.GZIP;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.orgmanagement.webapp.entity.MemoryProjectInvited;
import com.orgmanagement.webapp.entity.MemoryProject;
import com.google.gson.Gson;
import com.orgmanagement.webapp.dao.MemoryProjectInvitedDAO;
import com.orgmanagement.webapp.dao.MemoryProjectDAO;
import com.orgmanagement.webapp.util.AttributeCheck;
import com.orgmanagement.webapp.util.RandomGenerator;
import com.orgmanagement.webapp.util.SqlUtil;
import com.orgmanagement.webapp.util.UUIDGenerator;
import com.orgmanagement.webapp.util.entity.WebResponse;

@Path("/memoryProject")
@Controller
public class MemoryProjectRestController {
	 static final Logger LOGGER = LoggerFactory.getLogger(MemoryProjectRestController.class);
	 static final ApplicationContext CONTEXT_RDS = new ClassPathXmlApplicationContext("spring-module-rds.xml");
	
	/**
	 * 
	 * @param memoryProject
	 * *memoryProjectName 名稱

	 * @param request
	 * @param response
	 * @return
	 */
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response insert(MemoryProject memoryProject, @Context HttpServletRequest request, @Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");
		// init func
		
		// init variable
		final WebResponse webResponse = new WebResponse();	
		// verify loginToken
		if (true) {
			final UUIDGenerator uuidGenerator = new UUIDGenerator(); // UUID產生器
			final RandomGenerator randomGenerator = new RandomGenerator();// 亂數產生器		
			final String memoryProjectId = uuidGenerator.getUUID() + randomGenerator.getNumChar(4);
			memoryProject.setMemoryProjectId(memoryProjectId);
			//memoryProject.getMember().setLoginId("xxx");
			memoryProject.getMember().setMemberAccount("lulu");
			
			memoryProjectDAO.insert(memoryProject);
			webResponse.setData(memoryProject);
			webResponse.OK();
			System.out.println(new Gson().toJson(memoryProject));
			// write user behavior
//			final LogReport logReport = new LogReport();
//			logReport.setFunction("POST rest/memoryProject");
//			logReport.setSubject(loginToken);
//			logReport.setVerb("insertMemoryProject");
//			logReport.setObject(memoryProject);
//			LOGGER.info(new Gson().toJson(logReport));
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	@PATCH
	@Consumes(MediaType.APPLICATION_JSON)
	public Response udpate(MemoryProject memoryProject,@Context HttpServletRequest request,@Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");	
		// init variable
		final WebResponse webResponse = new WebResponse();
		// verify loginToken
		if (true) {
			final MemoryProject oldMemoryProject = memoryProjectDAO.get(memoryProject);
			memoryProjectDAO.update(memoryProject,oldMemoryProject);
			webResponse.setData(memoryProject);
			webResponse.OK();
			// write user behavior
//			final LogReport logReport = new LogReport();
//			logReport.setFunction("PATCH rest/memoryProject");
//			logReport.setVerb("updateMemoryProject");
//			logReport.setObject(memoryProject);
//			LOGGER.info(new Gson().toJson(logReport));
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	/**
	 * 
	 * @param memoryProjectId 單位編號
	 * @param request
	 * @param response
	 * @return
	 */
	@DELETE
	@Path("/{memoryProjectId}")
	public Response delete(@PathParam("memoryProjectId") String memoryProjectId, @Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");
		// init func
		
		// init variable
		final WebResponse webResponse = new WebResponse();
		
		
		// Check login token
		
		
		// verify loginToken
		if (true) {
			final MemoryProject memoryProject = new MemoryProject();
			memoryProject.setMemoryProjectId(memoryProjectId);
			memoryProjectDAO.delete(memoryProject);
			webResponse.setData(memoryProject);
			webResponse.OK();
			// write user behavior
//			final LogReport logReport = new LogReport();
//			logReport.setFunction("DELETE rest/memoryProject/{memoryProjectId}");
//			logReport.setVerb("updateMemoryProject");
//			logReport.setObject(memoryProject);
//			LOGGER.info(new Gson().toJson(logReport));
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	/**
	 * 
	 * @param memoryProjectId 編號
	 * @param request
	 * @param response
	 * @return
	 */
	@GET
	@GZIP
	@Path("/{memoryProjectId}")
	public Response get(@PathParam("memoryProjectId") String memoryProjectId, @Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");	
		// init variable
		final WebResponse webResponse = new WebResponse();
		// verify loginToken
		if (true) {
			MemoryProject memoryProject = new MemoryProject();
			memoryProject.setMemoryProjectId(memoryProjectId);
			memoryProject = memoryProjectDAO.get(memoryProject);
			webResponse.setData(memoryProject);
			webResponse.OK();
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}

	@GET
	@Path("/list")
	@GZIP
	public Response list(
			@DefaultValue("0") @QueryParam("offset") Integer offset,@DefaultValue("10") @QueryParam("limit")Integer limit,
			@QueryParam("search")String search,@Context HttpServletRequest request,@Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");	
		// init variable
		final WebResponse webResponse = new WebResponse();
		// verify loginToken
		if (true) {
			// init variable
			final SqlUtil sqlUtil = new SqlUtil();			
			// init limitSQL			
			sqlUtil.getLimitGenerator().setOffset(offset);
			sqlUtil.getLimitGenerator().setLimit(limit);
			// init likeSQL			
			sqlUtil.getLikeGenerator().getLikeFieldList().add("memoryProjectName");
			sqlUtil.getLikeGenerator().setLike(search);
			// init orderSQL
			sqlUtil.getOrderGenerator().setOrder("memoryProjectCreateDate");
			sqlUtil.getOrderGenerator().setAsc(false);		
			// Get List By ListFilter
			final List<MemoryProject> memoryProjectList = memoryProjectDAO.getList(sqlUtil);
			webResponse.setData(memoryProjectList);
			webResponse.OK();
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	@GET
	@Path("/listCount")
	@GZIP
	public Response listCount(
			@QueryParam("search")String search,
			@Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");
		// init func
		
		// init variable
		final WebResponse webResponse = new WebResponse();
		
		
		// Check login token
		
		
		// verify loginToken
		if (true) {
			// init variable
			final SqlUtil sqlUtil = new SqlUtil();
			// init likeSQL			
			sqlUtil.getLikeGenerator().getLikeFieldList().add("memoryProjectName");
			sqlUtil.getLikeGenerator().setLike(search);
			final int countTotal = memoryProjectDAO.countTotal(sqlUtil);
			webResponse.setData(countTotal);
			webResponse.OK();
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
	/**
	 * 檢查單位名稱是否重複
	 * @param memoryProjectName 單位名稱
	 * @param request
	 * @param response
	 * @return
	 */
	@POST
	@Path("/checkAvailable/memoryProjectName")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response checkMemoryProjectName(MemoryProject memoryProject, @Context HttpServletRequest request, @Context HttpServletResponse response) {
		// init DAO
		final MemoryProjectDAO memoryProjectDAO = (MemoryProjectDAO) CONTEXT_RDS.getBean("memoryProjectDAO");
		// init func
		
		// init variable
		final WebResponse webResponse = new WebResponse();
		
		
		// Check login token
		
		
		// verify loginToken
		if (true) {
			final boolean flag = memoryProjectDAO.checkName(memoryProject.getMemoryProjectName());
			if (flag) {
				webResponse.OK();
			} else {
				webResponse.CONFLICT();
				webResponse.getError().setMessage("memoryProjectName has already been taken");
				webResponse.setData(webResponse.getError());
			}
		} else {
			webResponse.getError().setMessage("Authentication failed");
			webResponse.setData(webResponse.getError());
			webResponse.UNAUTHORIZED();
		}
		return Response.status(webResponse.getStatusCode()).entity(webResponse.getData()).build();
	}
	
}