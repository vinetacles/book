package com.orgmanagement.webapp.dao;

import java.util.List;
import com.orgmanagement.webapp.entity.MemoryProjectInvited;
import com.orgmanagement.webapp.entity.MemoryProject;
import com.orgmanagement.webapp.entity.Member;
import com.orgmanagement.webapp.util.SqlUtil;


public interface MemoryProjectInvitedDAO {
	public void insert(MemoryProjectInvited memoryProjectInvited);

	public void update(MemoryProjectInvited memoryProjectInvited, MemoryProjectInvited oldMemoryProjectInvited);

	public void delete(MemoryProjectInvited memoryProjectInvited);

	public MemoryProjectInvited get(MemoryProjectInvited memoryProjectInvited);

	public List<MemoryProjectInvited> getList(SqlUtil sqlUtil);
	
	
//	
	public List<MemoryProjectInvited> getList_ByMemberAccount(SqlUtil sqlUtil, Member member);
	public List<MemoryProjectInvited> getList_ByMemoryProjectID(SqlUtil sqlUtil, MemoryProject memoryProject);
	
//  這邊要用member還是memoryProject?
	
	public int countTotal(SqlUtil sqlUtil);
	
	
//	
	public int countTotal_ByMemoryProjectID(SqlUtil sqlUtil, MemoryProject memoryProject);
	public int countTotal_ByMemberAccount(SqlUtil sqlUtil, Member member);
	
//  這邊要用member還是memoryProject?
//	
	public String getLastMemoryProjectInvitedNo_ByMemoryProjectID(MemoryProject memoryProject);
	public String getLastMemoryProjectInvitedNo_ByMemberAccount(Member member);
//

}
