package com.orgmanagement.webapp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.orgmanagement.webapp.dao.MemoryProjectDAO;
import com.orgmanagement.webapp.entity.MemoryProject;
import com.orgmanagement.webapp.entity.option.MemoryProjectOptionMapping;
import com.orgmanagement.webapp.util.SqlUtil;

public class MemoryProjectDAOImpl implements MemoryProjectDAO {
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	// 新增 MemoryProject
	public void insert(MemoryProject memoryProject) {
		Connection conn = null;
		PreparedStatement smt = null;
		final String sql = "INSERT INTO memory_project(memoryProjectId,memoryProjectName , memberAccount , memoryProjectCreateDate , memoryProjectUpdateDate) "
				+ "VALUES ( ? ,  ? ,  ? ,  NOW() ,  NOW() )";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memoryProject.getMemoryProjectId());
			smt.setString(2, memoryProject.getMemoryProjectName());
			smt.setString(3, memoryProject.getMember().getMemberAccount());
			smt.executeUpdate();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
	}

	// 更新 memoryProject
	public void update(MemoryProject memoryProject, MemoryProject oldMemoryProject) {
		Connection conn = null;
		PreparedStatement smt = null;
		final String sql = "UPDATE memory_project SET "
				+ " memoryProjectName = ? ,"
				+ " memoryProjectUpdateDate = NOW() "
				+ " WHERE memoryProjectId = ? ";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memoryProject.getMemoryProjectName() != null ? memoryProject.getMemoryProjectName():oldMemoryProject.getMemoryProjectName());
			smt.setString(2, memoryProject.getMemoryProjectId());
			smt.executeUpdate();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
	}

	// 刪除 memoryProject
	public void delete(MemoryProject memoryProject) {
		Connection conn = null;
		PreparedStatement smt = null;
		final String sql = "DELETE FROM memory_project WHERE memoryProjectId = ? ";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memoryProject.getMemoryProjectId());
			smt.executeUpdate();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
	}

	// 取得單筆 memoryProject
	public MemoryProject get(MemoryProject memoryProject) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		final MemoryProjectOptionMapping memoryProjectOptionMapping = new MemoryProjectOptionMapping();
		final String sql = "SELECT * FROM memory_project WHERE memoryProjectId = ? ";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memoryProject.getMemoryProjectId());
			rs = smt.executeQuery();
			memoryProject = new MemoryProject();
			if (rs.next()) {
				memoryProject.setMemoryProjectId(rs.getString("memoryProjectId"));
				memoryProject.setMemoryProjectName(rs.getString("memoryProjectName"));
				memoryProject.getMember().setMemberAccount(rs.getString("memberAccount"));
				memoryProject.setMemoryProjectCreateDate(rs.getDate("memoryProjectCreateDate"));
				memoryProject.setMemoryProjectUpdateDate(rs.getDate("memoryProjectUpdateDate"));
			}
			rs.close();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return memoryProject;
	}

	// 取多筆資料 memoryProject
	public List<MemoryProject> getList(SqlUtil sqlUtil) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		List<MemoryProject> memoryProjectList = new ArrayList<MemoryProject>();
		final MemoryProjectOptionMapping memoryProjectOptionMapping = new MemoryProjectOptionMapping();
		final String sql = "SELECT memoryProjectId , memoryProjectName "
				+ ", memberAccount , memoryProjectCreateDate , memoryProjectUpdateDate FROM memory_project "
				+ " WHERE "
				+ sqlUtil.getLikeGenerator().getLikeSql()
				+ sqlUtil.getOrderGenerator().getOrderSql()
				+ sqlUtil.getLimitGenerator().getLimitSql();
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			rs = smt.executeQuery();
			MemoryProject memoryProject;
			while (rs.next()) {
				memoryProject = new MemoryProject();
				memoryProject.setMemoryProjectId(rs.getString("memoryProjectId"));
				memoryProject.setMemoryProjectName(rs.getString("memoryProjectName"));
				memoryProject.getMember().setMemberAccount(rs.getString("memberAccount"));
				memoryProject.setMemoryProjectCreateDate(rs.getDate("memoryProjectCreateDate"));
				memoryProject.setMemoryProjectUpdateDate(rs.getDate("memoryProjectUpdateDate"));
				memoryProjectList.add(memoryProject);
			}
			rs.close();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return memoryProjectList;
	}
	
	// 計算資料量 memoryProject
	public int countTotal() {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		int countTotal = 0;
		final String sql = "SELECT COUNT(*) FROM memory_project";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			rs = smt.executeQuery();
			if (rs.next()) {
				countTotal = rs.getInt(1);
			}
			rs.close();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return countTotal;
	}

	// 計算資料量 memoryProject
	public int countTotal(SqlUtil sqlUtil) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		int countTotal = 0;	
		final String sql = "SELECT COUNT(*) FROM memory_project "
				+ " WHERE "
				+ sqlUtil.getLikeGenerator().getLikeSql();
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			rs = smt.executeQuery();
			if (rs.next()) {
				countTotal = rs.getInt(1);
			}
			rs.close();
			smt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return countTotal;
	}

	@Override
	public boolean checkName(String memoryProjectName) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		boolean flag = true;
		final String sql = "SELECT * FROM memory_project WHERE memoryProjectName = ?";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memoryProjectName);
			rs = smt.executeQuery();
			if(rs.next()){
				flag = false;
			}
			smt.executeQuery();	
			rs.close();
			smt.close();
 
		} catch (SQLException e) {
			throw new RuntimeException(e);
 
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		return flag;
	}
}
