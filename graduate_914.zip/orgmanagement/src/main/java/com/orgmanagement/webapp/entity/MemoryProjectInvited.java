package com.orgmanagement.webapp.entity;

import java.sql.Date;


public class MemoryProjectInvited {
	// DB Column
	
	private MemoryProject memoryProject = new MemoryProject();
	//********projectId要建嗎
	
	
	private Member memoryProjectMember = new Member();
	private String memoryProjectInvitedAccount;
	private String memoryProjectInvitedNo;
	
	
	private Date memoryProjectInvitedCreateDate;
	private Date memoryProjectInvitedUpdateDate;
	// 程式控制
	private String memoryProjectInvitedCreateDateString;
	private String memoryProjectInvitedUpdateDateString;
	private String memoryProjectInvitedStatus;
	
	public String getMemoryProjectInvitedAccount() {
		return memoryProjectInvitedAccount;
	}
	public void setMemoryProjectInvitedAccount(String memoryProjectInvitedAccount) {
		this.memoryProjectInvitedAccount = memoryProjectInvitedAccount;
	}
	public MemoryProject getMemoryProject() {
		return memoryProject;
	}
	public void setMemoryProject(MemoryProject memoryProject) {
		this.memoryProject = memoryProject;
	}
	
	public Member getMemoryProjectMember() {
		return memoryProjectMember;
	}
	public void setMemoryProjectMember(Member memoryProjectMember) {
		this.memoryProjectMember = memoryProjectMember;
	}
	public String getMemoryProjectInvitedNo() {
		return memoryProjectInvitedNo;
	}
	public void setMemoryProjectInvitedNo(String memoryProjectInvitedNo) {
		this.memoryProjectInvitedNo = memoryProjectInvitedNo;
	}
	public Date getMemoryProjectInvitedCreateDate() {
		return memoryProjectInvitedCreateDate;
	}
	public void setMemoryProjectInvitedCreateDate(Date memoryProjectInvitedCreateDate) {
		this.memoryProjectInvitedCreateDate = memoryProjectInvitedCreateDate;
	}
	public Date getMemoryProjectInvitedUpdateDate() {
		return memoryProjectInvitedUpdateDate;
	}
	public void setMemoryProjectInvitedUpdateDate(Date memoryProjectInvitedUpdateDate) {
		this.memoryProjectInvitedUpdateDate = memoryProjectInvitedUpdateDate;
	}
	public String getMemoryProjectInvitedCreateDateString() {
		return memoryProjectInvitedCreateDateString;
	}
	public void setMemoryProjectInvitedCreateDateString(String memoryProjectInvitedCreateDateString) {
		this.memoryProjectInvitedCreateDateString = memoryProjectInvitedCreateDateString;
	}
	public String getMemoryProjectInvitedUpdateDateString() {
		return memoryProjectInvitedUpdateDateString;
	}
	public void setMemoryProjectInvitedUpdateDateString(String memoryProjectInvitedUpdateDateString) {
		this.memoryProjectInvitedUpdateDateString = memoryProjectInvitedUpdateDateString;
	}
	public String getMemoryProjectInvitedStatus() {
		return memoryProjectInvitedStatus;
	}
	public void setMemoryProjectInvitedStatus(String memoryProjectInvitedStatus) {
		this.memoryProjectInvitedStatus = memoryProjectInvitedStatus;
	}
	
}
