package com.orgmanagement.webapp.dao;

import java.util.List;

import com.orgmanagement.webapp.entity.MemoryProject;
import com.orgmanagement.webapp.util.SqlUtil;


public interface MemoryProjectDAO {
	public void insert(MemoryProject memoryProject);
	public void update(MemoryProject memoryProject, MemoryProject olMemoryProject);
	public void delete(MemoryProject memoryProject);
	public MemoryProject get(MemoryProject memoryProject);
	public List<MemoryProject> getList(SqlUtil sqlUtil);
	public int countTotal();
	public int countTotal(SqlUtil sqlUtil);
	public boolean checkName(String memoryProjectName);
}
