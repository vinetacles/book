package com.orgmanagement.webapp.dao;

public interface SaveDAO {
	public String save(Object object);
	public void saveBatch(Object... object);
}
