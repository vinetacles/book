package com.orgmanagement.webapp.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateConversion {
	final AttributeCheck attributeCheck = new AttributeCheck();

	public String ConversionYMDHMSS_(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss.SSS");
		String DateString = formatter.format(date);
		return DateString;
	}

	public String ConversionYMDHMS(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String DateString = formatter.format(date);
		return DateString;
	}

	public String ConversionYMDHMS_(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss");
		String DateString = formatter.format(date);
		return DateString;
	}

	public String ConversionHMSbyGMT(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		String dateString = formatter.format(date);
		return dateString;
	}

	public String ConversionYMD_join(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public String ConversionYMD_(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public String ConversionYM_(Date date) {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM");
		String dateString = formatter.format(date);
		return dateString;
	}

	public Date StringtoYMD_(String dateString) throws ParseException {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = formatter.parse(dateString);
		return date;
	}

	public Date StringtoYMD(String dateString) {
		Date date = null;
		if (attributeCheck.stringsNotNull(dateString)) {
			try {
				final SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
				date = formatter.parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
			}	
		}	
		return date;
	}

	public String MDYtoYMD(String dateString) throws ParseException {
		final SimpleDateFormat MDYformatter = new SimpleDateFormat("MM/dd/yyyy");
		final SimpleDateFormat YMDformatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = MDYformatter.parse(dateString);
		String resultDateString = YMDformatter.format(date);
		return resultDateString;
	}

	public Date StringtoYMDHMS_(String dateString) throws ParseException {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = formatter.parse(dateString);
		return date;
	}

	public Date StringtoYMDHMSS_(String dateString) throws ParseException {
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss.SSS");
		Date date = formatter.parse(dateString);
		return date;
	}
}
