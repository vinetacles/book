package com.orgmanagement.webapp.dao;

import java.util.List;

import com.orgmanagement.webapp.entity.Member;
import com.orgmanagement.webapp.util.SqlUtil;

public interface MemberDAO {
	public void insert(Member member);

	public void update(Member member, Member oldMember);

	public void updatePassword(Member member);

	public Member get(Member member);

	public Member get_ByMemberNo(Member member);

	public List<Member> getList(Member member);

	public int countTotal();

	public boolean checkAccount(String memberAccount);

	public List<Member> getListbyIdentity(int i);

	public Member checkLogin(Member member);

	public List<Member> getListbyEmail(String account);



	

}
