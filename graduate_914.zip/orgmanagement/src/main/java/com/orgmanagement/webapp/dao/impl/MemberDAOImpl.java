package com.orgmanagement.webapp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.orgmanagement.webapp.dao.MemoryProjectDAO;
import com.orgmanagement.webapp.dao.MemberDAO;
import com.orgmanagement.webapp.entity.MemoryProject;
import com.orgmanagement.webapp.entity.Member;
import com.orgmanagement.webapp.entity.option.MemoryProjectOptionMapping;
import com.orgmanagement.webapp.util.SqlUtil;

public class MemberDAOImpl implements MemberDAO {
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	// 新增 Member
		public void insert(Member member) {
			Connection conn = null;
			PreparedStatement smt = null;
			final String sql = "INSERT INTO member(memberAccount, memberPassword, memberName , memberEmail , memberPhotoPath , isManager , memberRegisterDate , memberUpdateDate, memberResetPasswordDate) "
					+ "VALUES ( ? ,  ? ,  ? ,  ? ,  ? ,  ?  ,  NOW() ,  NOW(),  NOW() )";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				
				smt.setString(1, member.getMemberAccount());
				smt.setString(2, member.getMemberPassword());
				smt.setString(3, member.getMemberName());
				smt.setString(4, member.getMemberEmail());
				smt.setString(5, member.getMemberPhotoPath());
				smt.setInt(6, member.getIsManager());
				smt.executeUpdate();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
		}

		// 更新 Member
		public void update(Member member, Member oldMember) {
			Connection conn = null;
			PreparedStatement smt = null;
			final String sql = "UPDATE member SET memberName = ? , memberEmail = ?  ,"
					+ " memberUpdateDate = NOW()  "
					+ " WHERE memberAccount = ? ";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				smt.setString(1, member.getMemberName() != null ? member.getMemberName():oldMember.getMemberName());
				smt.setString(2, member.getMemberEmail() != null ? member.getMemberEmail():oldMember.getMemberEmail());
				
				smt.setString(3, member.getMemberAccount());
				smt.executeUpdate();
				smt.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
		}
		
		public void updatePassword(Member member) {
			Connection conn = null;
			PreparedStatement smt = null;
			final String sql = "UPDATE member SET memberPassword = ? , memberUpdateDate = NOW()  "
					+ " WHERE memberAccount = ? ";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				smt.setString(1, member.getMemberAccount());
				smt.setString(2, member.getMemberPassword());
				
				smt.executeUpdate();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
		}

		// 取得單筆 Member
		public Member get(Member member) {
			Connection conn = null;
			ResultSet rs = null;
			PreparedStatement smt = null;
			String sql = "SELECT * FROM member WHERE memberAccount = ? ";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				smt.setString(1, member.getMemberAccount());
				member = new Member();
				rs = smt.executeQuery();
				if (rs.next()) {
					
					member.setMemberAccount(rs.getString("memberAccount"));
					member.setMemberName(rs.getString("memberName"));
					member.setMemberPassword(rs.getString("memberPassword"));
					member.setMemberEmail(rs.getString("memberEmail"));
					
					
					member.setMemberRegisterDate(rs.getDate("memberRegisterDate"));
					member.setMemberUpdateDate(rs.getDate("memberUpdateDate"));
					member.setMemberResetPasswordDate(rs.getDate("memberResetPasswordDate"));
				}
				rs.close();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return member;
		}
		
		// 取得單筆 Member
		public Member get_ByMemberNo(Member member) {
			Connection conn = null;
			ResultSet rs = null;
			PreparedStatement smt = null;
			final String sql = "SELECT * FROM member "
					+ " WHERE memberAccount = ? ";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				smt.setString(1, member.getMemberAccount());
				rs = smt.executeQuery();
				if (rs.next()) {
					
					member.setMemberAccount(rs.getString("memberAccount"));
					member.setMemberName(rs.getString("memberName"));
					member.setMemberPassword(rs.getString("memberPassword"));
					member.setMemberEmail(rs.getString("memberEmail"));
					
					
					member.setMemberRegisterDate(rs.getDate("memberRegisterDate"));
					member.setMemberUpdateDate(rs.getDate("memberUpdateDate"));
					member.setMemberResetPasswordDate(rs.getDate("memberResetPasswordDate"));
				}
				rs.close();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return member;
		}

		// 取多筆資料 Member
		public List<Member> getList(SqlUtil sqlUtil) {
			Connection conn = null;
			ResultSet rs = null;
			PreparedStatement smt = null;
			List<Member> memberList = new ArrayList<Member>();
			final String sql = "SELECT * FROM member "
					+ " WHERE "
					+ sqlUtil.getLikeGenerator().getLikeSql()
					+ sqlUtil.getOrderGenerator().getOrderSql()
					+ sqlUtil.getLimitGenerator().getLimitSql();
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				rs = smt.executeQuery();
				Member member;
				while (rs.next()) {
					member = new Member();
					
					member.setMemberAccount(rs.getString("memberAccount"));
					member.setMemberName(rs.getString("memberName"));
					member.setMemberEmail(rs.getString("memberEmail"));
					member.setMemberPassword(rs.getString("memberPassword"));
					
					member.setMemberRegisterDate(rs.getDate("memberRegisterDate"));
					member.setMemberUpdateDate(rs.getDate("memberUpdateDate"));
					member.setMemberResetPasswordDate(rs.getDate("memberResetPasswordDate"));
					memberList.add(member);
				}
				rs.close();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return memberList;
		}

		// 計算資料量 Member
		public int countTotal() {
			Connection conn = null;
			ResultSet rs = null;
			PreparedStatement smt = null;
			int countTotal = 0;
			String sql = "SELECT COUNT(*) FROM member";
			try {
				conn = dataSource.getConnection();
				smt = conn.prepareStatement(sql);
				rs = smt.executeQuery();
				if (rs.next()) {
					countTotal = rs.getInt(1);
				}
				rs.close();
				smt.close();

			} catch (SQLException e) {

				throw new RuntimeException(e);

			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return countTotal;
		}
	

	
	@Override
	public boolean checkAccount(String memberAccount) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement smt = null;
		boolean flag = true;
		final String sql = "SELECT * FROM member WHERE memberAccount = ?";
		try {
			conn = dataSource.getConnection();
			smt = conn.prepareStatement(sql);
			smt.setString(1, memberAccount);
			rs = smt.executeQuery();
			if(rs.next()){
				flag = false;
			}
			smt.executeQuery();	
			rs.close();
			smt.close();
 
		} catch (SQLException e) {
			throw new RuntimeException(e);
 
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		return flag;
	}

	@Override
	public List<Member> getList(Member member) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Member> getListbyIdentity(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Member checkLogin(Member member) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Member> getListbyEmail(String account) {
		// TODO Auto-generated method stub
		return null;
	}


}
