package com.orgmanagement.webapp.entity;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.logicalcobwebs.cglib.core.TinyBitSet;

public class Member {
	// Database Column
	private String memberAccount;
	private String memberName;
	private String memberEmail;
	private String memberPassword;
	private String memberPhotoPath;
	private Date memberRegisterDate;
	private String memberRegisterDateString;
	private Date memberUpdateDate;
	private Date memberResetPasswordDate;
	// Program control
	private String memberUpdateDateString;
	private String memberResetPasswordDateString;
	private int isManager;



	public String getMemberPassword() {
		return memberPassword;
	}

	public void setMemberPassword(String memberPassword) {
		this.memberPassword = memberPassword;
	}

	public String getMemberPhotoPath() {
		return memberPhotoPath;
	}

	public void setMemberPhotoPath(String memberPhotoPath) {
		this.memberPhotoPath = memberPhotoPath;
	}

	public Date getMemberResetPasswordDate() {
		return memberResetPasswordDate;
	}

	public String getMemberAccount() {
		return memberAccount;
	}

	public void setMemberAccount(String memberAccount) {
		this.memberAccount = memberAccount;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}


	public Date getMemberRegisterDate() {
		return memberRegisterDate;
	}

	public void setMemberRegisterDate(Date memberRegisterDate) {
		this.memberRegisterDate = memberRegisterDate;
	}

	public String getMemberRegisterDateString() {
		return memberRegisterDateString;
	}

	public void setMemberRegisterDateString(String memberRegisterDateString) {
		this.memberRegisterDateString = memberRegisterDateString;
	}

	public Date getMemberUpdateDate() {
		return memberUpdateDate;
	}

	public void setMemberUpdateDate(Date memberUpdateDate) {
		this.memberUpdateDate = memberUpdateDate;
	}

	public Date getMemberPasswordResetDate() {
		return memberResetPasswordDate;
	}

	public void setMemberResetPasswordDate(Date memberResetPasswordDate) {
		this.memberResetPasswordDate = memberResetPasswordDate;
	}

	public String getMemberUpdateDateString() {
		return memberUpdateDateString;
	}

	public void setMemberUpdateDateString(String memberUpdateDateString) {
		this.memberUpdateDateString = memberUpdateDateString;
	}

	public String getMemberResetPasswordDateString() {
		return memberResetPasswordDateString;
	}

	public void setMemberResetPasswordDateString(String memberResetPasswordDateString) {
		this.memberResetPasswordDateString = memberResetPasswordDateString;
	}

	public int getIsManager() {
		return isManager;
	}

	public void setIsManager(int isManager) {
		this.isManager = isManager;
	}

	public void contactEmailManage(Member member, List<Member> managerList, HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

	public void setList(List<Member> memberList) {
		// TODO Auto-generated method stub
		
	}

	public boolean isLogin() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getStatus() {
		// TODO Auto-generated method stub
		return 0;
	}
}
