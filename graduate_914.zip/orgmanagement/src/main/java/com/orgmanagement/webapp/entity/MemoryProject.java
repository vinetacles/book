package com.orgmanagement.webapp.entity;

import java.sql.Date;

public class MemoryProject {
	private String memoryProjectId;
	private String memoryProjectName;
	private Member member = new Member();
	private Date memoryProjectCreateDate;
	private String memoryProjectCreateDateString;
	private Date memoryProjectUpdateDate;
	private String memoryProjectUpdateDateString;

	public String getMemoryProjectId() {
		return memoryProjectId;
	}

	public void setMemoryProjectId(String memoryProjectId) {
		this.memoryProjectId = memoryProjectId;
	}

	public String getMemoryProjectName() {
		return memoryProjectName;
	}

	public void setMemoryProjectName(String memoryProjectName) {
		this.memoryProjectName = memoryProjectName;
	}


	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Date getMemoryProjectCreateDate() {
		return memoryProjectCreateDate;
	}

	public void setMemoryProjectCreateDate(Date memoryProjectCreateDate) {
		this.memoryProjectCreateDate = memoryProjectCreateDate;
	}

	public String getMemoryProjectCreateDateString() {
		return memoryProjectCreateDateString;
	}

	public void setMemoryProjectCreateDateString(String memoryProjectCreateDateString) {
		this.memoryProjectCreateDateString = memoryProjectCreateDateString;
	}

	public Date getMemoryProjectUpdateDate() {
		return memoryProjectUpdateDate;
	}

	public void setMemoryProjectUpdateDate(Date memoryProjectUpdateDate) {
		this.memoryProjectUpdateDate = memoryProjectUpdateDate;
	}

	public String getMemoryProjectUpdateDateString() {
		return memoryProjectUpdateDateString;
	}

	public void setMemoryProjectUpdateDateString(String memoryProjectUpdateDateString) {
		this.memoryProjectUpdateDateString = memoryProjectUpdateDateString;
	}

	
}
