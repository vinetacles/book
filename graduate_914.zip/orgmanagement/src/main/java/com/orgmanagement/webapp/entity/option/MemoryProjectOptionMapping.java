package com.orgmanagement.webapp.entity.option;

import java.util.HashMap;

public class MemoryProjectOptionMapping {
	private static final HashMap<Integer, String> memoryProjectTypeHashMap = getMemoryProjectTypeHashMap();
	private static final HashMap<Integer, String> memoryProjectSourceHashMap = getOrganizationSourceHashMap();
	
	public static HashMap<Integer, String> getMemoryProjectTypeHashMap() {
		final HashMap<Integer, String>hashMap = new HashMap<>();
		hashMap.put(1, "協會");
		hashMap.put(2, "基金會");
		hashMap.put(3, "公部門");
		hashMap.put(4, "公辦民營");
		hashMap.put(5, "其他");
		return hashMap;
	}
	
	public String getOrganizationTypeString (Integer i) {
		return memoryProjectTypeHashMap.get(i);	
	}
	
	public static HashMap<Integer, String> getOrganizationSourceHashMap() {
		final HashMap<Integer, String>hashMap = new HashMap<>();
		hashMap.put(1, "");
		hashMap.put(2, "他人推薦");
		hashMap.put(3, "曾經上過相關課程");
		hashMap.put(4, "主動開發");
		hashMap.put(5, "其他");
		return hashMap;
	}
		
	public String getMemoryProjectSourceString (Integer i) {
		return memoryProjectSourceHashMap.get(i);	
	}
}
